
#setup CODE volume container
docker run -v /srv/codefiles:/srv/codefiles --name CODE centos:7 true
